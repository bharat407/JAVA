package com.example.demo.controller;

import com.example.demo.model.EventRegistration;
import com.example.demo.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class EventController {

    @Autowired
    private EventRegistrationRepository repo;

    // Show registration form
    @GetMapping("/")
    public String showForm(Model model) {
        model.addAttribute("event", new EventRegistration());
        return "register";
    }

    // Save registration
    @PostMapping("/register")
    public String save(@ModelAttribute("event") EventRegistration event) {
        repo.save(event);
        return "redirect:/participants";
    }

    // Show all participants
    @GetMapping("/participants")
    public String viewParticipants(Model model) {
        model.addAttribute("list", repo.findAll());
        return "viewParticipants";
    }

    // Edit participant
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable Long id, Model model) {
        EventRegistration event = repo.findById(id).orElse(null);
        model.addAttribute("event", event);
        return "register";
    }

    // Delete participant
    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        repo.deleteById(id);
        return "redirect:/participants";
    }
}
