package com.example.demo;

import com.example.demo.Feedback;
import com.example.demo.FeedbackRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class FeedbackController {

    @Autowired
    private FeedbackRepository feedbackRepository;

    @GetMapping("/")
    public String home() {
        return "home";
    }

    @GetMapping("/feedback/submit")
    public String showSubmitForm(Model model) {
        model.addAttribute("feedback", new Feedback());
        return "submitFeedback";
    }

    @PostMapping("/feedback/submit")
    public String submitFeedback(@Valid @ModelAttribute("feedback") Feedback feedback, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "submitFeedback";
        }
        feedbackRepository.save(feedback);
        return "redirect:/feedback/submit?success=true";
    }

    @GetMapping("/admin/view")
    public String viewFeedback(Model model) {
        model.addAttribute("feedbacks", feedbackRepository.findAll());
        return "viewFeedback";
    }
}